description=/data/adb/modules/adrenogpudriver/module.prop
mustbe="V@0842.8"
installed=$(strings /vendor/lib64/egl/libGLESv2_adreno.so | grep -i 'V@0')

sed -i '/description/d' /data/adb/modules/adrenogpudriver/module.prop

if [[ "$installed" == *"$mustbe"* ]]; then
  echo "description=📀 Adreno 830（OPenGL ES3.2-842.8)/ Status: Installed ✔️\n📱 Only 16 Android (Vulkan 1.4)\n📱 Only for devices to A8xx\n🖋️ Telegram support: t.me/OnePlus_11_12_13" >> $description
else
  echo "description=📀 Adreno 830（OPenGL ES3.2-842.8)/ Status: Not installed ✖️\n📱 Only 16 Android (Vulkan 1.4)\n📱 Only for devices to A8xx\n🖋️ Telegram support: t.me/OnePlus_11_12_13" >> $description

fi